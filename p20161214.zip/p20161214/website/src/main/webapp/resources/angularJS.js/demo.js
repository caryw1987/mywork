angular.module('myApp', [])
   .controller('myController', ['$scope', function($scope) {

       $scope.init = function() {
            $scope.name = "";   
       };  
       
//       $scope.alertOk = function() {
//           alert("OK");
//       };
       
//       $scope.count = 0;
//       $scope.$watch('name', function() {
//           //if( newValue === oldValue ) console.log("same value") return;
//           $scope.count++;
//           console.log("count : " + $scope.count + " ||  Time : " + new Date());
//       });       
   }]);