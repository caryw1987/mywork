angular.module('myApp', []).controller('userCtrl', function($scope, $http) {
	//$scope.name = '';
	$http({
		method : 'GET',
		url : 'getUserList'
	}).then(function successCallback(response) {
		$scope.users = response.data;
	}, function errorCallback(response) {

	});

	$scope.edit = true;
	$scope.error = false;
	$scope.incomplete = false;

	/*$scope.editUser = function(id) {
		if (id == 'new') {
			$scope.edit = true;
			$scope.incomplete = true;
			$scope.name = '';
		} else {
			$scope.edit = false;
			$scope.name = $scope.users[id - 1].name;
		}
	};*/

	$scope.save = function() {
		$http({
			method : 'POST',
			url : 'saveUser',
			data : {
				name : $scope.name
			}
		
		}).then(function successCallback(response) {
			$http({
				method : 'GET',
				url : 'getUserList'
			}).then(function successCallback(response) {
				$scope.users = response.data;

			}, function errorCallback(response) {

			});
		}, function errorCallback(response) {
		});
	};
	/*$scope.$watch('name', function() {
		$scope.test();
	});
	$scope.test = function() {
		$scope.incomplete = false;
		if ($scope.edit && (!$scope.name.length)) {
			$scope.incomplete = true;
		}
	};*/
});