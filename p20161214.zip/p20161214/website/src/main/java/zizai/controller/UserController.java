package zizai.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import zizai.model.User;
import zizai.service.UserService;

@Controller
@RequestMapping("user")
public class UserController {
	@Resource
	private UserService userService;
	
	@RequestMapping("/index")
	public ModelAndView toIndex(HttpServletRequest request){
		ModelAndView view = new ModelAndView("user/login");
		return view;
	}
	
	@RequestMapping("/editUser")
	public ModelAndView editUser(HttpServletRequest request){
		ModelAndView view = new ModelAndView("user/EditUser");
		return view;
	}
	
	@RequestMapping("/getUserList")
	@ResponseBody
	public List<User> getUserList(HttpServletRequest request, Model model) {
		
		List<User> users=this.userService.selectAll();
		return users;
	}
	
	@RequestMapping(value="/saveUser",method = RequestMethod.POST)
	@ResponseBody
	public String saveUser(HttpServletRequest request, Model model) {
		String name=request.getParameter("name");
		System.out.println(name);
		User user=new User();
		
		user.setName(name);
	//	System.out.println(user.toString());
	
		int update = this.userService.register(user);
		
		return "";
	}
	
	@RequestMapping("/index2")
	public ModelAndView toIndex2(HttpServletRequest request){
		ModelAndView view = new ModelAndView("user/login2");
		return view;
	}
	
	@RequestMapping("/test")
	public void test(HttpServletRequest request){
		String name = request.getParameter("name");
		String pwd = request.getParameter("pwd");
	}
	
/*
	@RequestMapping("/toRegister")
	public ModelAndView toregister(HttpServletRequest request,Model model){
		String url = "";
		 url = "user/register";
		ModelAndView view = new ModelAndView(url);
		return view;
	}
	
	@RequestMapping("/register")
	public ModelAndView register(HttpServletRequest request,Model model){
		String userName = request.getParameter("name");
		String pwd = request.getParameter("pwd");
		String url = "";
		User user = new User();
		if(userName!=null&&pwd!=null){
		user.setName(userName);
	//	user.setPwd(pwd);}
		int update = this.userService.register(user);
		if(update>0){
			url = "user/login";
		}else{
		 url = "user/register";}
		ModelAndView view = new ModelAndView(url);
		return view;
	}
	
	//�����û����޸�����
		@RequestMapping("/changePwd")
		public ModelAndView updateStudent(HttpServletRequest request, Model model) {
			String userName = request.getParameter("name");
			String password1 = request.getParameter("pwd1");
					User user = new User();
					user.setName(userName);
					user.setPwd(password1);
					int insert = this.userService.changPassword(user);
				
						String url = "user/login";
						ModelAndView view = new ModelAndView(url);
						return view;
		}
		
		 @RequestMapping("/updatepwd")
			public String updatePwd(@ModelAttribute("users") User user,HttpServletRequest request, Model model) {
				return "user/updatePwd";
			}*/
}
