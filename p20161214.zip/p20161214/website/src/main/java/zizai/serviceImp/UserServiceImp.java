package zizai.serviceImp;

import java.util.List;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import zizai.dao.UserMapper;
import zizai.model.User;
import zizai.service.UserService;

@Service("userService")
public class UserServiceImp implements UserService {
	@Resource
	private UserMapper userMapper;
	
	public User login(String name) {
		// TODO Auto-generated method stub
		return this.userMapper.selectByName(name);
	}
	
	public int register(User user) {
		// TODO Auto-generated method stub
		return this.userMapper.insert(user);
	}

	public int changPassword(User user) {
		// TODO Auto-generated method stub
		return this.userMapper.updatePwdByName(user);
	}

	public List<User> selectAll() {
		// TODO Auto-generated method stub
		return this.userMapper.selectAll();
	}

	

}
