package zizai.service;

import java.util.List;

import zizai.model.User;

public interface UserService {
	public int register(User user);
	public int changPassword(User user);
	public User login(String name);
	public List<User> selectAll();
}
