package com.zizaitianyuan.javac2.lesson03.shapes;

public interface Shape {

	public double perimeter();

	public String description();

}
