package com.zizaitianyuan.javac2.lesson06;

public enum Grade {
	A, B, C
}
