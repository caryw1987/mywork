package com.zizaitianyuan.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StaticMathsProxy implements Maths {

	private static Logger logger = LoggerFactory.getLogger(StaticMathsProxy.class);
	
	private Maths m;
	
	public StaticMathsProxy(Maths m) {
		this.m = m;
	}

	@Override
	public int add(int a, int b) {
		long start = System.currentTimeMillis();
		int result = m.add(a, b);
		long end = System.currentTimeMillis();
		
		logger.debug("add spend: {}", end - start);
		return result;
	}
}
