package com.zizaitianyuan.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zizaitianyuan.entities.User;
import com.zizaitianyuan.repositories.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;
	
	@Override
	public Iterable<User> getAllUsers() {
		return userRepository.findAll();
	}

	@Override
	@Transactional
	public User createUser(User user) {
		User u = new User();
		u.setAddress("Pudong");
		u.setName("Ada");
		userRepository.save(u);
		
		int a = 0;
		if ( a == 0) {
			throw new RuntimeException();
		}
		
		return userRepository.save(user);
	}

}
