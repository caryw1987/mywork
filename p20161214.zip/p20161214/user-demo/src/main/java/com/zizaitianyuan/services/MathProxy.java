package com.zizaitianyuan.services;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MathProxy implements InvocationHandler{

	private static Logger logger = LoggerFactory.getLogger(MathProxy.class);
	
	private Object m;
	
	public MathProxy(Object m) {
		this.m = m;
	}
	
	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		long start = System.currentTimeMillis();
		
		Object result = method.invoke(m, args);
		
		long end = System.currentTimeMillis();
		
		logger.debug("add spend: {}", end - start);
		return result;
	}

}
