package com.zizaitianyuan.services;

public interface Maths {

	public int add(int a, int b);
}
