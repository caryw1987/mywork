package com.zizaitianyuan.services;

import java.lang.reflect.Proxy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Main {

	private static Logger logger = LoggerFactory.getLogger(Main.class);
	
	public static void main(String[] args) {
		
		Maths m = new MathImpl();
		
//		m = new StaticMathsProxy(m);
		
		m = (Maths) Proxy.newProxyInstance(Maths.class.getClassLoader(), 
				new Class[] {Maths.class}, new MathProxy(m));
		
		logger.debug(" 5 + 6 = {}", m.add(5,  6));
		
	}

}
